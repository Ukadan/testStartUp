//
//  LoginView.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//
import SwiftUI
import AuthenticationServices
import GoogleSignIn
import FirebaseAuth
import CryptoKit

struct LoginView: View {
    @StateObject private var viewModel = AuthViewModel()
    @EnvironmentObject var authState: AuthState
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var nonce: String = ""
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.blue.opacity(0.8), .purple.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Text("StartUp")
                    .font(.system(size: 48, weight: .bold, design: .rounded))
                    .foregroundColor(.white)
                    .shadow(color: .black.opacity(0.2), radius: 5, x: 0, y: 2)
                
                Text("Вход в приложение")
                    .font(.title2)
                    .foregroundColor(.white.opacity(0.9))
                
//                SignInWithAppleButton(
//                    .signIn,
//                    onRequest: { request in
//                        nonce = viewModel.randomNonceString()
//                        request.requestedScopes = [.fullName, .email]
//                        request.nonce = viewModel.sha256(nonce)
//                    },
//                    onCompletion: { result in
//                        Task {
//                            let authResult = await viewModel.handleAppleSignInCompletion(result: result, nonce: nonce)
//                            handleAuthResult(authResult)
//                        }
//                    }
//                )
//                .frame(height: 50)
//                .signInWithAppleButtonStyle(.white)
//                .cornerRadius(10)
//                .shadow(color: .gray.opacity(0.3), radius: 5)
                
                Button(action: {
                    Task {
                        let authResult = await viewModel.signInWithGoogle()
                        handleAuthResult(authResult)
                    }
                }) {
                    HStack {
                        Image(systemName: "g.circle.fill")
                            .foregroundColor(.red)
                            .font(.title2)
                        Text("Войти через Google")
                            .font(.headline)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.white)
                    .foregroundColor(.black)
                    .cornerRadius(10)
                    .shadow(color: .gray.opacity(0.3), radius: 5)
                }
            }
            .padding(.horizontal, 40)
        }
        .alert("Ошибка", isPresented: $showAlert) {
            Button("OK") { }
        } message: {
            Text(alertMessage)
        }
        .onChange(of: viewModel.isAuthenticated) {
            if $0 {
                authState.isLoggedIn = true
            }
        }
    }
    
    private func handleAuthResult(_ result: Result<AuthResponse, Error>) {
        switch result {
        case .success(let response):
            KeychainHelper.saveToken(response.accessToken)
            authState.userName = response.me.name
            authState.isLoggedIn = true
        case .failure(let error):
            alertMessage = error.localizedDescription
            showAlert = true
        }
    }
}


