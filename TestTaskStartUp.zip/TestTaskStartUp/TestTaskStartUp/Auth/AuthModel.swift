//
//  AuthModel.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import Foundation

struct JSONRPCResponse: Decodable {
    let jsonrpc: String
    let result: AuthResponse?
    let id: Int
}

struct AuthResponse: Decodable {
    let accessToken: String
    let me: User
}

struct User: Decodable {
    let id: Int
    let name: String
}
