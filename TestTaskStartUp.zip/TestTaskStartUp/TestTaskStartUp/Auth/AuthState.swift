//
//  AuthState.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//


import Foundation

class AuthState: ObservableObject {
    @Published var isLoggedIn: Bool = false
    @Published var userName: String = "Пользователь"
    
    init() {
        if let token = KeychainHelper.loadToken(), !token.isEmpty {
            isLoggedIn = true
        }
    }
}
