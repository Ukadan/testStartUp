//
//  AuthViewModel.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import Foundation
import Firebase
import FirebaseAuth
import GoogleSignIn
import AuthenticationServices
import Network
import CryptoKit

@MainActor
class AuthViewModel: ObservableObject {
    @Published var isAuthenticated = false
    @Published var error: Error?
    
    func randomNonceString(length: Int = 32) -> String {
        var randomString = ""
        let letters = "abcdefABCDEF1234567890"
        for _ in 0..<length {
            randomString += String(letters.randomElement()!)
        }
        return randomString
    }
    
    func sha256(_ input: String) -> String {
        let inputData = Data(input.utf8)
        let hashedData = SHA256.hash(data: inputData)
        let hashString = hashedData.compactMap {
            String(format: "%02x", $0)
        }.joined()
        return hashString
    }
    
    func handleAppleSignInCompletion(result: Result<ASAuthorization, Error>, nonce: String) async -> Result<AuthResponse, Error> {
        switch result {
        case .success(let authorization):
            guard let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential else {
                return .failure(NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "Неверные credentials"]))
            }
            guard let appleIDToken = appleIDCredential.identityToken else {
                return .failure(NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "Неверный токен"]))
            }
            guard let idTokenString = String(data: appleIDToken, encoding: .utf8) else {
                return .failure(NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "Неверная строка токена"]))
            }
            let credential = OAuthProvider.appleCredential(withIDToken: idTokenString, rawNonce: nonce, fullName: appleIDCredential.fullName)
            return await performSignIn(with: credential)
        case .failure(let error):
            return .failure(error)
        }
    }
    
    func signInWithGoogle() async -> Result<AuthResponse, Error> {
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            return .failure(NSError(domain: "Config", code: -1, userInfo: [NSLocalizedDescriptionKey: "Отсутствует clientID"]))
        }
        
        let config = GIDConfiguration(clientID: clientID)
        
        do {
            guard let presentingViewController = UIApplication.shared.windows.first?.rootViewController else {
                return .failure(NSError(domain: "UI", code: -1, userInfo: [NSLocalizedDescriptionKey: "Нет presenting VC"]))
            }
            
            let signInResult = try await GIDSignIn.sharedInstance.signIn(withPresenting: presentingViewController)
            guard let idToken = signInResult.user.idToken?.tokenString else {
                return .failure(NSError(domain: "Auth", code: -1, userInfo: [NSLocalizedDescriptionKey: "Нет ID токена"]))
            }
            let accessToken = signInResult.user.accessToken.tokenString
            let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
            return await performSignIn(with: credential)
        } catch {
            return .failure(error)
        }
    }
    
    private func performSignIn(with credential: AuthCredential) async -> Result<AuthResponse, Error> {
        do {
            let authResult = try await Auth.auth().signIn(with: credential)
            let idToken = try await authResult.user.getIDToken()
            return try await sendTokenToBackend(idToken: idToken)
        } catch {
            return .failure(error)
        }
    }
    
    private func sendTokenToBackend(idToken: String) async throws -> Result<AuthResponse, Error> {
        let url = URL(string: "https://api.court360.ai/rpc/client")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "jsonrpc": "2.0",
            "method": "auth.firebaseLogin",
            "params": ["fbIdToken": idToken],
            "id": 1
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            return .failure(NSError(domain: "HTTP", code: (response as? HTTPURLResponse)?.statusCode ?? 0, userInfo: [NSLocalizedDescriptionKey: "Ошибка ответа сервера"]))
        }
        
        let jsonResponse = try JSONDecoder().decode(JSONRPCResponse.self, from: data)
        guard let result = jsonResponse.result else {
            return .failure(NSError(domain: "API", code: -1, userInfo: [NSLocalizedDescriptionKey: "Нет результата в ответе"]))
        }
        return .success(result)
    }
}
