//
//  ContentView.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import SwiftUI
import Firebase

struct ContentView: View {
    @EnvironmentObject var authState: AuthState
        
    var body: some View {
        NavigationStack {
            if authState.isLoggedIn {
                WelcomeView()
            } else {
                LoginView()
            }
        }
        .navigationBarHidden(true)
    }
}

