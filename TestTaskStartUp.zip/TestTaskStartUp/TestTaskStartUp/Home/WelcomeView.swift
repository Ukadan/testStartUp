//
//  WelcomeView.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import SwiftUI

struct WelcomeView: View {
    @EnvironmentObject var authState: AuthState
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.green.opacity(0.8), .blue.opacity(0.6)]), startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                Text("Добро пожаловать, \(authState.userName)!")
                    .font(.largeTitle)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                    .padding(.top, 100)
                
                NavigationLink(destination: MainView()) {
                    Text("Перейти к главному экрану")
                        .font(.headline)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.white)
                        .foregroundColor(.blue)
                        .cornerRadius(10)
                        .shadow(color: .gray.opacity(0.3), radius: 5)
                }
                .padding(.horizontal, 40)
            }
        }
        .navigationBarHidden(true)
    }
}
