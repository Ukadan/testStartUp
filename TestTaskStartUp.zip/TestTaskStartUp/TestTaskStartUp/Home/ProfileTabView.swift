//
//  ProfileTabView.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import SwiftUI

struct ProfileTabView: View {
    var body: some View {
        VStack {
            Text("Ваш профиль")
                .font(.title)
                .padding()
            
            Circle()
                .fill(Color.gray)
                .frame(width: 100, height: 100)
                .overlay(Text("Фото").foregroundColor(.white))
            
            Text("Имя: Пользователь")
                .padding()
        }
    }
}
