//
//  MainView.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            HomeTabView()
                .tabItem {
                    Label("Домой", systemImage: "house.fill")
                }
            
            ProfileTabView()
                .tabItem {
                    Label("Профиль", systemImage: "person.fill")
                }
        }
        .accentColor(.blue)
        .navigationBarTitle("Главный экран", displayMode: .inline)
    }
}
