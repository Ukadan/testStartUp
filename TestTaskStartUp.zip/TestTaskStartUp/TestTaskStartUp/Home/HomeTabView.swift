//
//  HomeTabView.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//

import SwiftUI

struct HomeTabView: View {
    var body: some View {
        VStack {
            Text("Добро пожаловать на главный экран!")
                .font(.title)
                .padding()
            
            List {
                Text("Элемент 1")
                Text("Элемент 2")
                Text("Элемент 3")
            }
            .listStyle(.insetGrouped)
        }
    }
}
