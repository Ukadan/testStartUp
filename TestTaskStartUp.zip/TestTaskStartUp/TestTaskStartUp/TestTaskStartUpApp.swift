//
//  TestTaskStartUpApp.swift
//  TestTaskStartUp
//
//  Created by Ali on 07.09.2025.
//
import SwiftUI
import FirebaseCore
import GoogleSignIn

@main
struct TestTaskStartUpApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    init() {
        FirebaseApp.configure()
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(AuthState())
                .preferredColorScheme(.light)
        }
    }
}


